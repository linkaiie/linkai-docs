import type { BaseLayoutProps } from 'fumadocs-ui/layouts/shared';

export function baseOptions(): BaseLayoutProps {
  return {
    links: [
      { type: 'main', text: 'Docs', url: '/docs' },
      { type: 'main', text: 'Quickstart', url: '/docs/getting-started' },
      { type: 'main', text: 'API Reference', url: '/docs/gateway-api' },
      { type: 'main', text: 'Billing', url: '/docs/billing-credits' },
    ],
    nav: {
      title: 'LinkAI Route',
      url: '/',
    },
  };
}
