(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_fumadocs-ui_dist_components_dialog_search-default_1e34228e.js",
  "static/chunks/node_modules_00f9907a._.js",
  "static/chunks/[root-of-the-server]__94e4fccf._.css"
],
    source: "dynamic"
});
