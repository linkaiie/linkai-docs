module.exports = [
"[project]/.next-internal/server/app/docs/[[...slug]]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_docs_%5B%5B___slug%5D%5D_page_actions_13cf9669.js.map